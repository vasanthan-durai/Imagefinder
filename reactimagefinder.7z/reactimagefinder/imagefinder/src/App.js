import './App.css';
import UserInfo from './UserInfo';
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  return (
    <div className="App">
      <UserInfo></UserInfo>
    </div>
  );
}

export default App;
